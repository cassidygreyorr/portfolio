/**
 * Server
 * 
 * A server listening on port 15001 and waiting for client connections. 
 * This server reads from the client. 
 *
 * This services each request in a separate thread.
 *
 * @author - Greg Gagne.
 * Modified by - Cassidy Orr
 */

import java.net.*;
import java.io.*;
import java.util.concurrent.*;
import java.util.*;

public class Server
{
   public static final int DEFAULT_PORT = 15001;
   
    // construct a thread pool for concurrency	
   private static final Executor exec = Executors.newCachedThreadPool();
	
   public static void main(String[] args) throws IOException {
	   ServerSocket sock = null;
   	
      try {
      	// establish the socket
    	  
          Vector<String> messageQueue = new Vector<String>();
          ArrayList<BufferedWriter> clients = new ArrayList<BufferedWriter>();
          Runnable broadcast = new BroadcastThread(messageQueue, clients);
          exec.execute(broadcast);
          sock = new ServerSocket(DEFAULT_PORT);
    	  
      	
         while (true) {
         	/**
         	 * now listen for connections
         	 * and service the connection in a separate thread.
         	 */
        	Socket client = sock.accept();
            BufferedWriter toClient = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            clients.add(toClient);
            Runnable task = new connection(client, messageQueue);
            exec.execute(task);
         }
      }
      catch (IOException ioe) { System.err.println(ioe); }
      finally {
         if (sock != null)
            sock.close();
      }
   }
}