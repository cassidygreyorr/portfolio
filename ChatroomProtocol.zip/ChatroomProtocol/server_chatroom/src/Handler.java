/** 
 * Handler class
 * 
 * Reads message from the Client and adds it to the message queue. 
 * 
 * @author Greg Gagne 
 * Modified by - Cassidy Orr
 */

import java.io.*;
import java.util.*;
import java.net.*;

public class Handler 
{
	
	/**
	 * this method is invoked by a separate thread
	 */
	public void process(Socket client, Vector<String> messageQueue) throws java.io.IOException {

		BufferedReader fromClient = null;
		
		try {
			/**
			 * get the input and output streams associated with the socket.
			 */
			String line;
			
			fromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
			
			/** reads from the client */
			while ((line = fromClient.readLine()) != null) {
					
				messageQueue.add(line);
			}
			
   		}
		catch (IOException ioe) {
			System.err.println(ioe);
		}
		finally {
			// close streams and socket
			if (fromClient != null)
				fromClient.close();
			
		}
	}
}