/**
 * BroadcastThread
 * 
 * Check if there are any messages in the Vector. If so, remove them
 * and broadcast the messages to the chat room.
 *
 * @author - Greg Gagne.
 * Modified by - Cassidy Orr
 */


import java.util.Vector;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.*;

public class BroadcastThread implements Runnable
{
	private Vector<String> messageQueue = new Vector<String>();
	private ArrayList<BufferedWriter> clients = new ArrayList<BufferedWriter>();
	
	public BroadcastThread(Vector<String> messageQueue, ArrayList<BufferedWriter> clients) {
		this.messageQueue = messageQueue;
		this.clients = clients;
	}
	
	
    public void run() {
        while (true) {
            // sleep for 1/10th of a second
        	
        	try { Thread.sleep(100); } catch (InterruptedException ignore) { }
            
            while (messageQueue.size() != 0){
            	String message = messageQueue.get(0);
            	messageQueue.remove(0);
            	for (int i=0; i < clients.size(); i++) {
            		try {
						clients.get(i).write(message + "\n");
						clients.get(i).flush();
						System.out.println(message);
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						clients.remove(i);
						e.printStackTrace();
					}
            	}
            }
            
        }
    }
} 