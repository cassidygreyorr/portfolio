/**
 * Connection class
 * 
 * This is the separate thread that services each
 * incoming client request.
 *
 * @author Greg Gagne 
 * Modified by - Cassidy Orr
 */

import java.net.*;
import java.util.ArrayList;
import java.io.*;
import java.util.*;

public class connection implements Runnable
{
	private Socket client;
	private Vector<String> messQueue;
	private static Handler handler = new Handler();
	
	public connection(Socket client, Vector<String> messageQueue) {
		this.client = client;
		this.messQueue = messageQueue;
	}

    /**
     * This method runs in a separate thread.
     */	
	public void run() { 
		try {
			handler.process(client, messQueue);
		}
		catch (java.io.IOException ioe) {
			System.err.println(ioe);
		}
	}
}
