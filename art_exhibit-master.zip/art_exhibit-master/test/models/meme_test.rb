require "test_helper"

class MemeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
