import React from 'react';

const Projects = () => {
  return (
    <div>
      <h1>PROJECTS</h1>
    </div>
  );
};

export default Projects;