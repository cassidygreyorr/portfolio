import React from 'react';

const Resources = () => {
  return (
    <div style={{color: 'white', textAlign: 'center'}}>
      <h1>Resources</h1>
      <p>https://www.maa.org/press/periodicals/convergence/mathematical-treasure-leibnizs-papers-on-calculus</p>

<p>https://www.storyofmathematics.com/17th_leibniz.html</p>

<p>https://tutorial.math.lamar.edu/classes/calcI/minmaxvalues.aspx</p>

<p>https://activecalculus.org/single/images/1_7_Cont.svg</p>
<p>https://www.storyofmathematics.com/17th_newton.html</p>

<p>https://activecalculus.org.html</p>

<p>https://activecalculus.org/single/images/1_8_Options.svg </p>


<p>https://activecalculus.org/single/images/1_3_SecToTanSeq.svg</p>
<div style={{textAlign: 'center', marginTop: '100px'}}>
<h3>This project brushes on these learning targets</h3>
<p>PC1, PC2, DM2*, DM7*,  DU1*, DU4*, DU5, DU6
</p>
</div>
    </div>
  );
};

export default Resources;