class Meme < ApplicationRecord
end
