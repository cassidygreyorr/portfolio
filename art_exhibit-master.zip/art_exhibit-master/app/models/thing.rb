class Thing < ApplicationRecord
end
