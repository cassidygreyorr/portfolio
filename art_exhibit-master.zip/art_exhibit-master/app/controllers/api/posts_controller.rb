class Api::PostsController < ApplicationController
end
