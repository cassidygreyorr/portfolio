import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;

public class Ship extends Polygon implements KeyListener {
	public static final int SCREEN_WIDTH = 800;
	public static final int SCREEN_HEIGHT = 600;
	public static final int SHIP_WIDTH = 40;
	public static final int SHIP_HEIGHT = 25;
	Point[] poly;
	int[] xA, yA;
	Point temp;
	boolean forward = false;
	boolean left = false;
	boolean right = false;
	boolean space = false;
	boolean release = true;
	ArrayList<Bullet> bullets = new ArrayList<Bullet>();
	

	public Ship(Point[] shape, Point position, double rotation) {
		super(shape, position, rotation);
		// TODO Auto-generated constructor stub
		xA = new int[shape.length];
		yA = new int[shape.length];
		poly = new Point[shape.length];
	}

	@Override
	public void paint(Graphics brush, Color color) {
		// TODO Auto-generated method stub
		poly = super.getPoints();
		for(int i = 0; i < poly.length; i++) {
			temp = poly[i];
			xA[i] = (int) temp.x;
			yA[i] = (int) temp.y;
		}
		
		brush.setColor(color);
		brush.drawPolygon(xA, yA, poly.length);
		brush.fillPolygon(xA, yA, poly.length);
	}

	@Override
	public void move() {
//IF I WANTED TO MAKE THE SHIP GO TO THE OTHER SIDE
				/**
				 * If the ship moves off of the screen either along the
				 * x or y axis, have the ship re-appear coming from the other side.
				 */
			/*
				if(position.x > Asteroids.SCREEN_WIDTH) {
					position.x -= Asteroids.SCREEN_WIDTH;
				} 
				else if(position.x < 0) {
					position.x += Asteroids.SCREEN_WIDTH;
				}
				if(position.y > Asteroids.SCREEN_HEIGHT) {
					position.y -= Asteroids.SCREEN_HEIGHT;
				} 
				else if(position.y < 0) {
					position.y += Asteroids.SCREEN_HEIGHT;
				}
				else {
					if(left) 
						this.rotate(-5);
					if(right) 
						this.rotate(5);
					if(forward) {
						position.x += 3 * Math.cos(Math.toRadians(super.rotation));
						position.y += 3 * Math.sin(Math.toRadians(super.rotation));
					}	
				}*/

//IF I WANT MY SHIP TO BOUNCE OF THE EDGES
		if(position.x > SCREEN_WIDTH) {
			position.x = position.x - 1;
			super.rotation = ((super.rotation + 270) * -1) + 90;
		}
		else if(position.x < 0) {
			position.x = position.x + 1;
			super.rotation = ((super.rotation + 270) * -1) + 90;
		}
		
		if(position.y > SCREEN_HEIGHT) {
			position.y = position.y - 1;
			super.rotation = super.rotation * -1;
		}
		else if(position.y < 0) {
			position.y = position.y + 1;
			super.rotation = super.rotation * -1;
		}
		
		else {
			if(left) 
				this.rotate(-5);
			if(right) 
				this.rotate(5);
			if(forward) {
				position.x += 3 * Math.cos(Math.toRadians(super.rotation));
				position.y += 3 * Math.sin(Math.toRadians(super.rotation));
			}
		}
		
//fires bullets 		
		if(space) {
			Point[] front = super.getPoints();
			Bullet b = new Bullet(front[3], super.rotation);
			bullets.add(b);		 
		}
		space = false;
		
	}
	
	//returns bullet ArrayList
	public ArrayList<Bullet> getBullets(){
		return bullets;
	}

//Controls the ships movements and the bullets
	@Override
	public void keyTyped(KeyEvent e) {
		if(release == true) {
			if(e.getKeyChar() == ' ') { 
				space = true;
				release = false;
			}
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyCode() == KeyEvent.VK_UP) {
			forward = true;
		}
		
		if(e.getKeyCode() == KeyEvent.VK_LEFT) {
			left = true;
			this.rotate(-10);
		}
		
		if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
			right = true;
			this.rotate(10);
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyCode() == KeyEvent.VK_UP) 
			forward = false;
			
		if(e.getKeyCode() == KeyEvent.VK_LEFT) 
			left = false;
			
		if(e.getKeyCode() == KeyEvent.VK_RIGHT) 
			right = false;
		
		if(e.getKeyCode() == KeyEvent.VK_SPACE) {
			release = true;
			space = false;
		}
	}

}
