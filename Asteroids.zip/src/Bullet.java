import java.awt.Color;
import java.awt.Graphics;

public class Bullet extends Circle {
	public static int radius = 6;
	public static final int SCREEN_WIDTH = 800;
	public static final int SCREEN_HEIGHT = 600;
	double rotation;
	
	public Bullet(Point center, double rotation) {
		super(center, radius);
		this.rotation = rotation;
	}

	@Override
	public void paint(Graphics brush, Color color) {
		brush.setColor(color);
		brush.fillOval((int) super.center.x, (int) super.center.y, radius, radius);
	}

	@Override
	public void move() {
		center.x += 4 * Math.cos(Math.toRadians(rotation));
		center.y += 4 * Math.sin(Math.toRadians(rotation));
	}
	
	//determines whether a bullet is off of the screen 
	public boolean outOfBounds() {
		if (center.x > SCREEN_WIDTH || center.x < 0)
			return true;
		
		else if (center.y > SCREEN_HEIGHT || center.y < 0)
			return true;
		
		else
			return false;
	}
	
	//returns the center Point of a bullet
	public Point getCenter(Bullet b) {
		return b.center;
	}

}
