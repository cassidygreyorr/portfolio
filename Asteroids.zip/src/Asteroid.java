import java.awt.Color;
import java.util.Random;
import java.awt.Graphics;

public class Asteroid extends Polygon {
	public static final int SCREEN_WIDTH = 800;
	public static final int SCREEN_HEIGHT = 600;
	Point[] poly;
	int[] xA, yA;
	Point temp;
	double rot;	
	
	public Asteroid(Point[] shape, Point position, double rotation) {
		super(shape, position, rotation);
		xA = new int[shape.length];
		yA = new int[shape.length];
		poly = new Point[shape.length];
		rot = rotation;
	}

	@Override
	public void paint(Graphics brush, Color color) {
		/* 		Gets the points of the polygon and uses them to draw the Polygon		*/
		
		//ADDS EACH X AND Y VALUES TO THE APPROPRIATE ARRAY
		poly = super.getPoints();
		for(int i = 0; i < poly.length; i++) {
			temp = poly[i];
			xA[i] = (int) temp.x;
			yA[i] = (int) temp.y;
		}
		
		brush.setColor(color);
		brush.drawPolygon(xA, yA, poly.length);		
	}

	@Override
	public void move() {
		/* 		Moves the Asteroid across the canvas by adjusting the offset (position)		 */
		if(position.x > SCREEN_WIDTH) {
			position.x = position.x - 1;
			rot = ((rot + 270) * -1) + 90;
		}
		else if(position.x < 0) {
			position.x = position.x + 1;
			rot = ((rot + 270) * -1) + 90;
		}
		
		else if(position.y > SCREEN_HEIGHT) {
			position.y = position.y - 1;
			rot = rot * -1;
		}
		else if(position.y < 0) {
			position.y = position.y + 1;
			rot = rot * -1;
		}
		else {
			position.x += Math.cos(Math.toRadians(rot));
			position.y += Math.sin(Math.toRadians(rot));
		}
	}

}
