
/*
CLASS: AsteroidsGame
DESCRIPTION: Extending Game, Asteroids is all in the paint method.
NOTE: This class is the metaphorical "main method" of your program,
      it is your control center.
Original code by Dan Leyzberg and Art Simon
Added code by Cassidy Orr
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import javax.swing.Timer;


public class Asteroids extends Game {
	public static final int SCREEN_WIDTH = 800;
	public static final int SCREEN_HEIGHT = 600;
	public Ship ship;
	static int counter = 0;
	int time;
	int lives;
	boolean coll;
	boolean prevColl;
	private Random rand = new Random();
	private ArrayList<Bullet> bull;
	private java.util.List<Asteroid> randomAsteroids;
	private Star[] randomStars;
	ArrayList<Bullet> removedB = new ArrayList<>();
	ArrayList<Asteroid> removedA = new ArrayList<>();
	
	public Asteroids() {
		super("Asteroids!", SCREEN_WIDTH, SCREEN_HEIGHT);
		this.setFocusable(true);
		this.requestFocus();
		
		//creates stars, asteroids and the ship
		randomStars = createStars(1000, 5);
		randomAsteroids = createRandomAsteroids(10,60,30);
		ship = createShip();
		this.addKeyListener(ship);
		lives = 5;
	}
	
	// private helper method to create the Ship
		private Ship createShip() {
	        // Look of ship
	        Point[] shipShape = {
	                new Point(0, 0),
	                new Point(Ship.SHIP_WIDTH/3.5, Ship.SHIP_HEIGHT/2),
	                new Point(0, Ship.SHIP_HEIGHT),
	                new Point(Ship.SHIP_WIDTH, Ship.SHIP_HEIGHT/2)
	        };
	        // Set ship at the middle of the screen
	        Point startingPosition = new Point((width -Ship.SHIP_WIDTH)/2, (height - Ship.SHIP_HEIGHT)/2);
	        int startingRotation = 0; // Start facing to the right
	        return new Ship(shipShape, startingPosition, startingRotation);
	    }

	
//  Create an array of random asteroids
	private java.util.List<Asteroid> createRandomAsteroids(int numberOfAsteroids, int maxAsteroidWidth,
			int minAsteroidWidth) {
		java.util.List<Asteroid> asteroids = new ArrayList<>(numberOfAsteroids);

		for(int i = 0; i < numberOfAsteroids; ++i) {
			// Create random asteroids by sampling points on a circle
			// Find the radius first.
			int radius = (int) (Math.random() * maxAsteroidWidth);
			if(radius < minAsteroidWidth) {
				radius += minAsteroidWidth;
			}
			// Find the circles angle
			double angle = (Math.random() * Math.PI * 1.0/2.0);
			if(angle < Math.PI * 1.0/5.0) {
				angle += Math.PI * 1.0/5.0;
			}
			// Sample and store points around that circle
			ArrayList<Point> asteroidSides = new ArrayList<Point>();
			double originalAngle = angle;
			while(angle < 2*Math.PI) {
				double x = Math.cos(angle) * radius;
				double y = Math.sin(angle) * radius;
				asteroidSides.add(new Point(x, y));
				angle += originalAngle;
			}
			// Set everything up to create the asteroid
			Point[] inSides = asteroidSides.toArray(new Point[asteroidSides.size()]);
			Point inPosition = new Point(Math.random() * SCREEN_WIDTH, Math.random() * SCREEN_HEIGHT);
			double inRotation = Math.random() * 360;
			asteroids.add(new Asteroid(inSides, inPosition, inRotation));
		}
		return asteroids;
	}
	
// Create a certain number of stars with a given max radius
	public Star[] createStars(int numberOfStars, int maxRadius) {
	         Star[] stars = new Star[numberOfStars];
	         for(int i = 0; i < numberOfStars; ++i) {
	                 Point center = new Point(Math.random() * SCREEN_WIDTH, Math.random() * SCREEN_HEIGHT);
	                 int radius = (int) (Math.random() * maxRadius);
	                 if(radius < 1) {
	                         radius = 1;
	                 }
	                 stars[i] = new Star(center, radius);
	         }
	         return stars;
	 }

	
//Called over and over, paints the screen, determines: collisions, number of lives, whether the player has won or lost.
	public void paint(Graphics brush) {
		prevColl = coll;	//determines whether to decrement lives
		brush.setColor(Color.black);
		brush.fillRect(0,0,width,height);
				// sample code for printing message for debugging
				// counter is incremented and this message printed
				// each time the canvas is repainted
		counter++;
		brush.setColor(Color.white);
		brush.drawString("Counter is " + counter,10,10);
		brush.drawString("Lives: " + lives,10,25);
		
		// Where we call the paint() and move() methods on our objects		
		ship.move();
		bull = ship.getBullets();
		for(Bullet bullet : bull) {
			bullet.paint(brush, Color.green);
			bullet.move();
			
			if(bullet.outOfBounds() == true) 
				removedB.add(bullet);
			
			for(Asteroid a : randomAsteroids) {
				if(a.contains(bullet.center)) {
					removedA.add(a);
					removedB.add(bullet);
				}
			}
		}
		
		//garbage functions
		for(Bullet b : removedB) {
			if(bull.contains(b))
				bull.remove(b);
		}
		for(Asteroid a : removedA) {
			if(randomAsteroids.contains(a)) 
				randomAsteroids.remove(a);
		}
		
		//TWINKLE TWINKLE
		for(Star star : randomStars) {
			int n = rand.nextInt(randomStars.length);
			if(n < 30) {
				star.paint(brush, Color.black);
			}
			else
				star.paint(brush,  Color.cyan);
				
		}
		
		time--;
		for (Asteroid asteroid : randomAsteroids) {
			asteroid.paint(brush,Color.white);
			asteroid.move();
			//detecting collisions ! ! !
			if(asteroid.collision(ship)) {
				coll = true;
				time = 1;
			}
		}
		
		//decrement lives
		if(prevColl == false && coll == true)
			lives--;
		//painting ship when collision is true
		if(time > 0) {
			ship.paint(brush, Color.red);
			coll = true;
		}
		
		else {
			ship.paint(brush, Color.magenta);
			coll = false;
		}
		
		//LOST AND END OF THE GAME
		if(lives == 0) {
			brush.setColor(Color.black);
			brush.fillRect(0,0,width,height);
			brush.setColor(Color.white);
			brush.drawString("YOU LOST ", 350, 300);
			on = false;
		}
		
		//WON AND END OF THE GAME
		if(randomAsteroids.isEmpty()/* && lives > 0*/) {
			brush.setColor(Color.black);
			brush.fillRect(0,0,width,height);
			brush.setColor(Color.white);
			brush.drawString("YOU WON ", 350, 300);
			on = false;
		}
	}

	public static void main (String[] args) {
		Asteroids a = new Asteroids();
		a.repaint(); // calls paint
		
	}
}