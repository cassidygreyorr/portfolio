package com.example.keep_in_touch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /// Fragment Manager
        FragmentManager fragmentManager = getSupportFragmentManager();

        /// Code for Type Button to switch fragments
        Button btnlisten = findViewById(R.id.btnListen);


        btnlisten.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                fragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerView3, ListenFragment.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("name") // name can be null
                        .commit();
            }
        });

        /// Code for Type Button to switch fragments
        Button btntype = findViewById(R.id.btnType);
        btntype.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                fragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerView3, TypeFragment.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("name") // name can be null
                        .commit();
            }
        });


        /// Code for Save Button to switch fragments
        Button btnsave = findViewById(R.id.btnSave);
        btnsave.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                fragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerView3, SaveFragment.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("name") // name can be null
                        .commit();
            }
        });


        /// Code for Profile Button to switch fragments
        Button btnprofile = findViewById(R.id.btnProfile);
        btnprofile.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                fragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerView3, ProfileFragment.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("name") // name can be null
                        .commit();
            }
        });
    }
}