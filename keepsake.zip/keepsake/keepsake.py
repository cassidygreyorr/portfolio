#!/usr/bin/env python3

# @author:
# with modifications: cassidy orr

import mysql.connector
import os.path
from db_tunnel import DatabaseTunnel

# Default connection information (can be overridden with command-line arguments)
# Change these as needed for your app. (You should create a token for your database and use its username
# and password here.)
DB_NAME = "cgo0416_keepsake"
DB_USER = "token_0067"
DB_PASSWORD = "E9w46V08Nl9NC9fn"

# SQL queries/statements that will be used in this program (replace these with the queries/statements needed
# by your program)

# Search for a user by id
USER_BY_ID = """
    SELECT name
    FROM User
    WHERE id = %s
"""

# Use "%s" as a placeholder for where you will need to insert values (e.g., user input)

# Add a new user
ADD_NEW_USER = """
    INSERT INTO User (id, name) VALUES (%s, %s)
"""

# Show User Categories
QUERY_USER_CATEGORIES = """
    SELECT id, name
    FROM Category
    WHERE user_id = %s
"""

# Show text
SHOW_TEXT = """
    SELECT text
    FROM Text
    WHERE Text.id = %s
"""

# Show all my texts
QUERY_TEXTS = """
    SELECT id, text
    FROM Text
    WHERE Text.user_id = %s
"""

# Show texts in categories
QUERY_TEXTS_IN_CATEGORY = """
    SELECT Text.id, Text.text
    FROM Text
    WHERE Text.user_id = %s and Text.cat_id = %s
"""

# Show texts related to type
QUERY_TEXTS_BY_TYPE = """
    SELECT text
    FROM Text
    INNER JOIN TextType on Text.id = TextType.text_id
    INNER JOIN Type on TextType.type_id = Type.id
    WHERE Type.name like %s
"""

# Show all types
SHOW_TYPES = """
    SELECT *
    FROM Type
"""

# Search for texts by keyword
TEXT_BY_KEYWORD = """
    SELECT Category.name, Text.id, Text.text
    FROM Text
    INNER JOIN Category on Text.cat_id = Category.id
    WHERE Text.user_id = %s and text like %s
"""

# My stuff
MY_STUFF = """
    SELECT Category.id, Category.name, Text.id, Text.text
    FROM Text
    INNER JOIN Category on Text.cat_id = Category.id
    WHERE Text.user_id = %s
"""

# Add category
ADD_CATEGORY = """
    INSERT INTO Category (name, user_id) VALUES (%s, %s)
"""

# Add text
ADD_TEXT = """
    INSERT INTO Text (text, cat_id, user_id) VALUES (%s, %s, %s)
"""

# Add text
ADD_TEXTTYPE = """
    INSERT INTO TextType (text_id, type_id) VALUES (%s, %s)
"""

# Find text id
FIND_TEXT = """
    SELECT MAX(Text.id)
    FROM Text
"""

# Shows most recently used texts
QUERY_MOST_RECENTLY_USED_TEXTS = """
    SELECT id, text, date_used
    FROM Text
    WHERE user_id = %s
    ORDER BY date_used DESC
"""

# Drop category
DROP_CATEGORY = """
    DELETE FROM Category
    WHERE id = %s 
"""

# Drop text
DROP_TEXT = """
    DELETE FROM Text
    WHERE id = %s
"""

# Drop texttype
DROP_TEXTTYPE = """
    DELETE FROM TextType
    WHERE text_id = %s
"""

# Show type stats
TYPE_STATS = """
    SELECT Type.name, count(Text.text)
    FROM TextType
    INNER JOIN Type ON TextType.type_id = Type.id
    INNER JOIN Text ON TextType.text_id = Text.id
    WHERE Text.user_id = %s
    GROUP BY Type.id
"""

# Show Most frequent type stats
MOST_FREQUENT_TYPE_STATS = """
    SELECT MaxType.name, MaxType.total
    FROM Type
    INNER JOIN (
        SELECT Type.name, count(Text.text) AS total
        FROM TextType
        INNER JOIN Type ON TextType.type_id = Type.id
        INNER JOIN Text ON TextType.text_id = Text.id
        WHERE Text.user_id = %s
        GROUP BY Type.id
    ) AS MaxType ON Type.name = MaxType.name
    ORDER BY MaxType.total DESC
    LIMIT 1
    
"""


# If you change the name of this class (and you should) you also need to change it in main() near the bottom
class keepsake:
    '''A simple Python application that interfaces with a database.'''

    def __init__(self, dbHost, dbPort, dbName, dbUser, dbPassword):
        self.dbHost, self.dbPort = dbHost, dbPort
        self.dbName = dbName
        self.dbUser, self.dbPassword = dbUser, dbPassword

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.close()

    def connect(self):
        self.connection = mysql.connector.connect(
            host=self.dbHost, port=self.dbPort, database=self.dbName,
            user=self.dbUser, password=self.dbPassword,
            use_pure=True,
            autocommit=True,
        )
        self.cursor = self.connection.cursor()

    def close(self):
        self.connection.close()

    def runApp(self):
        # The main loop of your program
        # Take user input here, then call methods that you write below to perform whatever
        # queries/tasks your program needs.

        # SIGN IN USER
        user_id = input(
            "\n Sign in (or hit Enter to quit) \nUser ID: ")
        name = self.userById(user_id)

        # NEW USER
        if not name:
            yes_no = input("You are not in our system yet, would you like to be added? (y/n)\n")
            if yes_no == 'y':
                name = input("Type your full name\n")
                self.addNewUser(user_id, name)
            else:
                return
        print(f"\nWelcome, {name}")

        while True:

            # MENU
            answer = input("\n\nWhat would you like to do?\n     a) My stuff\n     b) Text Stats\n     c) Most recent texts \n     q) Quit\n==> ")

            # MY STUFF
            if answer == "a":
                print("\nMy Categories: ")
                self.showUserCategories(user_id)

                answer = input("\nNow what?\n     a) Search category\n     b) Add category\n     c) Drop category\n     d) Search for text\n     e) All my texts\n     q) Quit\n")

                # SEARCH A CATEGORY
                if answer == "a":
                    cat_id = input("\nEnter id of the category to search: ")
                    temp = self.showTextsInCategory(user_id, cat_id)
                    if temp == 0:
                        print("\nWhoops! You either don't have a category with that id, or you have no texts in this category.")
                    else:
                        temp = input("\nWould you like to display any of these texts? (y/n)\n")
                        if temp == "y":
                            text_id = input("\nEnter id of the text to display: \n")
                            temp = self.showText(text_id)
                            if temp == 0:
                                print("\nWhoops! You don't have a text with that id.")
                        elif temp == "n":
                            print("Okerr")
                        else:
                            print("invalid input")

                # ADD A CATEGORY
                elif answer == "b":
                    added = input("Enter the name of the category to add (e.g. General): ")
                    self.addCategory(added, user_id)
                    print("\n" + added + " added!")

                # DROP A CATEGORY
                elif answer == "c":
                    dropped = input("Enter the id of the category to drop: ")

                    answer = input("\nAll texts in this category will be dropped, are you sure you want to proceed? (y/n)\n")
                    if answer == 'y':
                        self.dropCategory(dropped)
                        print("\n     dropped!")
                    elif answer == 'n':
                        print("aight")
                    else:
                        print("invalid input")


                # SEARCH FOR TEXT BY KEYWORD
                elif answer == "d":
                    k = input("Enter keyword to search for: ")
                    keyword = "%" + k + "%"
                    temp = self.searchTextsByKeyword(user_id, keyword)
                    if temp == 0:
                        print("\nWhoops! You don't have texts with that keyword.")
                    else:
                        temp = input("\nWould you like to display any of these texts? (y/n)\n")
                        if temp == "y":
                            text_id = input("\nEnter id of the text to display: \n")
                            temp = self.showText(text_id)
                            if temp == 0:
                                print("\nWhoops! You don't have a text with that id.")
                        elif temp == "n":
                            print("K.")
                        else:
                            print("invalid input")

                # ALL USER TEXTS
                elif answer == "e":
                    print("\nMy Texts:")
                    self.queryTexts(user_id)

                    answer = input("\nNow what?\n     a) Display text\n     b) Add text\n     c) Drop text\n     q) Quit\n")

                    # DISPLAY TEXT
                    if answer == "a":
                        text_id = input("\nEnter id of the text to display: \n")
                        temp = self.showText(text_id)
                        if temp == 0:
                            print("\nWhoops! You don't have a text with that id.")

                    # ADD A TEXT
                    elif answer == "b":
                        added = input("Enter the text to add: ")
                        print("\nYour Categories: ")
                        self.showUserCategories(user_id)
                        cat_id = input("\nEnter the id of the category it should be stored in: ")
                        print("\n")
                        text_id = self.findText()
                        self.showTypes()
                        type_id = input("\nEnter the type id of this text: ")
                        if int(type_id) > 4 or int(type_id) < 1:
                            print("Not an option, your text has not been added")
                        else:
                            self.addText(added, cat_id, user_id)
                            self.addTextType(text_id, type_id)
                            print("\n Text added!")

                    # DROP A TEXT
                    elif answer == "c":
                        self.queryTexts(user_id)
                        dropped = input("\nEnter the id of the text to drop: ")
                        self.dropText(dropped)
                        self.dropTextType(dropped)
                        print("\n Text dropped!\n")
                        self.queryTexts(user_id)

                    elif answer == "q":
                        break
                    else:
                        print("invalid input")

                elif answer == "q":
                    break
                else:
                    print("invalid input")


            elif answer == "b":
                print("\nMost popular type: ")
                self.mostFrequentTypeStats(user_id)
                print("\nAll stats: ")
                self.typeStats(user_id)

            # MOST RECENT TEXTS
            elif answer == "c":
                print("\n")
                temp = self.showMostRecent(user_id)
                if temp == 0:
                    print("\nWhoops! You don't have any texts")
                else:
                    temp = input("\nWould you like to display any of these texts? (y/n)\n")
                    if temp == "y":
                        text_id = input("\nEnter id of the text to display: \n")
                        self.showText(text_id)
                    elif temp == "n":
                        print("K.")
                    else:
                        print("invalid input")

            elif answer == "q":
                return

            else:
                print("You typed an invalid input. Try again!\n")

    # Add one method here for each database operation your app will perform, then call them from runApp() above

    # SIGN IN USER
    def userById(self, id):
        self.cursor.execute(USER_BY_ID, (id,))
        for (name,) in self.cursor:
            return name

    # ADD A USER
    def addNewUser(self, id, name):
        self.cursor.execute(ADD_NEW_USER, (id, name))

    # MY STUFF
    def myStuff(self, user_id):
        self.cursor.execute(MY_STUFF, (user_id,))
        for (cat_id, cat_name, text_id, text) in self.cursor:
            print(f"  {cat_id:2d}   {cat_name}\n     {text_id:2d}     {text}")

    # SHOW USER CATEGORIES
    def showUserCategories(self, user_id):
        self.cursor.execute(QUERY_USER_CATEGORIES, (user_id,))
        for (id, name) in self.cursor:
            print(f"  {id:2d}   {name}")

    # SEARCH A CATEGORY
    def showTextsInCategory(self, user_id, cat_id):
        count = 0
        self.cursor.execute(QUERY_TEXTS_IN_CATEGORY, (user_id, cat_id))
        for (text_id, text) in self.cursor:
            if text:
                count = 1
            print(f"  {text_id:2d}   {text}")
        return count


    # SEARCH FOR TEXT BY KEYWORD
    def searchTextsByKeyword(self, user_id, keyword):
        count = 0
        self.cursor.execute(TEXT_BY_KEYWORD, (user_id, keyword))
        for (cat_name, text_id, text) in self.cursor:
            if text:
                count = 1
            print(f"\nCategory: {cat_name}\n     {text_id:2d}     {text}")
        return count

    # ADD A CATEGORY
    def addCategory(self, added, user_id):
        self.cursor.execute(ADD_CATEGORY, (added, user_id))

    # ADD A TEXT
    def addText(self, added, cat_id, user_id):
        self.cursor.execute(ADD_TEXT, (added, cat_id, user_id))

    # FIND TEXT FOR ADDING TYPE
    def findText(self):
        self.cursor.execute(FIND_TEXT)
        for (text_id,) in self.cursor:
            return text_id + 1

    # DROP A CATEGORY
    def dropCategory(self, cat_id):
        self.cursor.execute(DROP_CATEGORY, (cat_id, ))

    # DROP A TEXT
    def dropText(self, text_id):
        self.cursor.execute(DROP_TEXT, (text_id, ))

    # DROP A TEXTTYPE
    def dropTextType(self, text_id):
        self.cursor.execute(DROP_TEXTTYPE, (text_id,))

    # SHOW MOST RECENT TEXTS
    def showMostRecent(self, user_id):
        count = 0
        self.cursor.execute(QUERY_MOST_RECENTLY_USED_TEXTS, (user_id,))
        for (text_id, text, date_used) in self.cursor:
            if text:
                count = 1
            print(f"  {text_id:2d}   {text:64s}   {date_used}")
        return count

    # SHOW TYPES
    def showTypes(self):
        # Execute the query
        self.cursor.execute(SHOW_TYPES)
        for (type_id, type,) in self.cursor:
            print(f"     {type_id:2d}     {type}")

    # ADD TYPE TO TEXT
    def addTextType(self, text_id, type_id):
        # Execute the query
        self.cursor.execute(ADD_TEXTTYPE, (text_id, type_id))

    # SHOW TYPE STATS
    def typeStats(self, user_id):
        # Execute the query
        self.cursor.execute(TYPE_STATS, (user_id,))

        for (type, count) in self.cursor:
            print(f"     {type:15s}     {count}")

    # SHOW TYPE STATS
    def mostFrequentTypeStats(self, user_id):
        # Execute the query
        self.cursor.execute(MOST_FREQUENT_TYPE_STATS, (user_id,))

        for (type, total) in self.cursor:
            print(f"     {type:15s}     {total} total")


    def showText(self, id):
        # Execute the query
        count = 0
        self.cursor.execute(SHOW_TEXT, (id,))
        for (text,) in self.cursor:
            if text:
                count = 1
            print(f"     {text}")
        return count

    def queryTexts(self, user_id):
        # Execute the query
        self.cursor.execute(QUERY_TEXTS, (user_id,))

        for (id, text) in self.cursor:
            print(f" {id:2d} {text}")




def main():
    import sys
    '''Entry point of the application. Uses command-line parameters to override database connection settings, then invokes runApp().'''
    # Default connection parameters (can be overridden on command line)
    params = {
        'dbname': DB_NAME,
        'user': DB_USER,
        'password': DB_PASSWORD
    }

    needToPrintHelp = False

    # Parse command-line arguments, overriding values in params
    i = 1
    while i < len(sys.argv) and not needToPrintHelp:
        arg = sys.argv[i]
        isLast = (i + 1 == len(sys.argv))

        if arg in ("-h", "-help"):
            needToPrintHelp = True
            break

        elif arg in ("-dbname", "-user", "-password"):
            if isLast:
                needToPrintHelp = True
            else:
                params[arg[1:]] = sys.argv[i + 1]
                i += 1

        else:
            print("Unrecognized option: " + arg, file=sys.stderr)
            needToPrintHelp = True

        i += 1

    # If help was requested, print it and exit
    if needToPrintHelp:
        printHelp()
        return

    try:
        with \
                DatabaseTunnel() as tunnel, \
                keepsake(
                    dbHost='localhost', dbPort=tunnel.getForwardedPort(),
                    dbName=params['dbname'],
                    dbUser=params['user'], dbPassword=params['password']
                ) as app:

            try:
                app.runApp()
            except mysql.connector.Error as err:
                print("\n\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-", file=sys.stderr)
                print("SQL error when running database app!\n", file=sys.stderr)
                print(err, file=sys.stderr)
                print("\n\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-", file=sys.stderr)

    except mysql.connector.Error as err:
        print("Error communicating with the database (see full message below).", file=sys.stderr)
        print(err, file=sys.stderr)
        print("\nParameters used to connect to the database:", file=sys.stderr)
        print(f"\tDatabase name: {params['dbname']}\n\tUser: {params['user']}\n\tPassword: {params['password']}",
              file=sys.stderr)
        print("""
(Did you install mysql-connector-python and sshtunnel with pip3/pip?)
(Are the username and password correct?)""", file=sys.stderr)


def printHelp():
    print(f'''
Accepted command-line arguments:
    -help, -h          display this help text
    -dbname <text>     override name of database to connect to
                       (default: {DB_NAME})
    -user <text>       override database user
                       (default: {DB_USER})
    -password <text>   override database password
    ''')


if __name__ == "__main__":
    main()
